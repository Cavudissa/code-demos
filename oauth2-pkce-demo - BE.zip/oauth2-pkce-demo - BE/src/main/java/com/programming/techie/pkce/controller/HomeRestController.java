package com.programming.techie.pkce.controller;


import com.programming.techie.pkce.todoList.Todo;
import com.programming.techie.pkce.todoList.TodoHardcodedService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static org.springframework.http.HttpStatus.OK;

@RestController
@RequestMapping("/api")
@CrossOrigin( origins = "*")
public class HomeRestController {

    @Autowired
    private TodoHardcodedService todoService;

    @GetMapping("/home")
    @ResponseStatus(OK)
    public String home(){
        return  "Hellooooo";
    }

    @GetMapping("/list")
    public List<Todo> getAllTodos(@PathVariable String username){
        return todoService.findAll();
    }


}
