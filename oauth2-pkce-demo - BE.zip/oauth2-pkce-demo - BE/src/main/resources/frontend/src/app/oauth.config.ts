import {AuthConfig} from "angular-oauth2-oidc";
import { Scope } from 'eslint-scope';

export const  authConfig: AuthConfig = {

    issuer: 'http://localhost:8180/auth/realms/oath2-demo-realm',
    redirectUri: window.location.origin,
    clientId: 'oauth2-demo-pkce-client',
    responseType: 'code',
    strictDiscoveryDocumentValidation : true, // when the list of endpoints exposed by issuer urls endpoint does not contain the same base url as issuer endpoint,
    scope: 'openid profile email offline_access'

}