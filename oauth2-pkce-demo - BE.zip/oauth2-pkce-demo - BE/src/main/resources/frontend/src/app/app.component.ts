import { Component, OnDestroy } from '@angular/core';
import { OAuthService } from 'angular-oauth2-oidc';
import { authConfig } from './oauth.config';
import { AppService } from './app.service';
import { Subscription } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnDestroy {

  title = 'frontend';
  text = '';
  helloSubscription : Subscription;

  constructor (private oauthService: OAuthService,
               private appService: AppService,
               private router: Router){
    this.configue();
    this.helloSubscription = this.appService.hello()
    .subscribe(response=>{
      this.text = response;
      console.log(response);

    })
  }

  private configue(){
    this.oauthService.configure(authConfig)
    this.oauthService.loadDiscoveryDocumentAndTryLogin()
  }

  login(){

    console.log("Promise"); 
    this.oauthService.initCodeFlow();
    this.oauthService.loadUserProfile()
    .then(function(value) {
      console.log(value); // Success!
    }, function(reason) {
      console.log(reason); // Error!
    });
  }

  logout (){
    this.oauthService.logOut();
  }
  ngOnDestroy(): void {
   this.helloSubscription.unsubscribe();
  }

  getList() {
    this.router.navigate(['todos'])
  }
}
