import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Todo } from './todo-list/todo-list.component';

@Injectable({
  providedIn: 'root'
})
export class AppService {

  constructor(private httpClient: HttpClient) { }


  hello(): Observable<string>{
    const headers = new HttpHeaders().set('content-type', 'text/plan; charset=utf-8')
    return this.httpClient.get("http://localhost:8080/api/home",
    {headers, responseType:'text'});
  }


  findUserTodos(){

    console.log(`http://localhost:8080/api/list`);
    return this.httpClient.get<Todo[]>(`http://localhost:8080/api/list`
    )
    
  }



}
