import { Component, OnInit } from '@angular/core';
import { AppService } from '../app.service';

@Component({
  selector: 'app-todo-list',
  templateUrl: './todo-list.component.html',
  styleUrls: ['./todo-list.component.css']
})
export class TodoListComponent implements OnInit {
  todos:Todo[] = [];
  message: string =''
  constructor( private appService: AppService) { }

  ngOnInit() {
    console.log("Todlist chegueii");
    this.refreshTodos();
  
    }
  
    refreshTodos(){
      this.appService.findUserTodos()
      .subscribe((response:Todo[])=>{
        console.log(response);
            this.todos = response;
            console.log(this.todos)
      })
    }
  

}

export class Todo {
  constructor(
    public id: number,
    public description: string,
    public status: boolean,
    public targetDate: Date
  ){

  }
}

